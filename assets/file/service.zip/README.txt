Service Read MIFARE JM
by : Ashrul
======================

Pemakaian :
- Pastikan JRE versi 8_241 : kalau tidak bisa download di : kunpong.jmto.co.id/operasional/assets/file/JRE_64bit_v8_Update_241.exe
- Ekstrak Semua File Service.Zip
- Klik service.bat dan Window Akan terbuka, dan service siap digunakan.
- Pastikan Window service tetap berjalan. jangan ditutup.
